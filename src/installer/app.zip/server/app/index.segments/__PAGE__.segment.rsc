1:"$Sreact.fragment"
2:I[97367,["/_next/static/chunks/2f236954d6a65e12.js"],"OutletBoundary"]
3:"$Sreact.suspense"
0:{"buildId":"5XkrA2wv0TZKBms2sQvVZ","rsc":["$","$1","c",{"children":[["$","main",null,{"className":"min-h-screen bg-neutral-900"}],null,["$","$L2",null,{"children":["$","$3",null,{"name":"Next.MetadataOutlet","children":"$@4"}]}]]}],"loading":null,"isPartial":false}
4:null
